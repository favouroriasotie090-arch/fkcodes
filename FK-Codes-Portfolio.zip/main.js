const $ = (selector, parent = document) => parent.querySelector(selector);
const $$ = (selector, parent = document) => [...parent.querySelectorAll(selector)];

const menuBtn = $("#menuBtn");
const nav = $("#nav");
const themeBtn = $("#themeBtn");

menuBtn.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  menuBtn.setAttribute("aria-expanded", open);
});

$$(".nav a").forEach(link => link.addEventListener("click", () => nav.classList.remove("open")));

const savedTheme = localStorage.getItem("fk-theme");
if (savedTheme) document.documentElement.dataset.theme = savedTheme;

function updateThemeIcon() {
  themeBtn.textContent = document.documentElement.dataset.theme === "light" ? "☾" : "☼";
}
updateThemeIcon();

themeBtn.addEventListener("click", () => {
  const light = document.documentElement.dataset.theme === "light";
  if (light) delete document.documentElement.dataset.theme;
  else document.documentElement.dataset.theme = "light";
  localStorage.setItem("fk-theme", document.documentElement.dataset.theme || "dark");
  updateThemeIcon();
});

const projects = {
  orderflow: {
    type: "Business web app",
    title: "FK OrderFlow",
    description: "A practical concept for small businesses that need a simple way to organize products, prices, quantities and customer orders without a complicated dashboard.",
    details: "<b>Focus:</b> product data, order logic, pricing calculations, responsive UI and browser storage.<br><br><b>Next step:</b> connect a backend/database and authentication for real customer accounts."
  },
  notepad: {
    type: "Productivity app",
    title: "FK Notepad",
    description: "A browser-based notes project built to practice CRUD-style interactions, persistence and UI state.",
    details: "<b>Focus:</b> localStorage, JSON, note creation, deletion, selection, themes and statistics.<br><br><b>Lesson:</b> making data survive a page refresh changes a simple interface into a useful little application."
  },
  dictionary: {
    type: "Search experience",
    title: "Offline Dictionary",
    description: "An offline dictionary concept that uses local JSON word data instead of requiring a live dictionary API for every lookup.",
    details: "<b>Focus:</b> search, filtering, suggestions, JSON data and performance considerations.<br><br><b>Lesson:</b> large local datasets need thoughtful loading and search strategies."
  },
  bakery: {
    type: "Business website",
    title: "Fresh Baked",
    description: "A bakery website concept focused on product presentation, responsive layout and a clear customer journey.",
    details: "<b>Focus:</b> visual hierarchy, responsive design, product cards and conversion-focused calls to action.<br><br><b>Potential client use:</b> adapt the structure for a real bakery, restaurant or food business."
  },
  weather: {
    type: "Utility app",
    title: "Weather App",
    description: "A learning project for understanding asynchronous JavaScript, API requests, loading states and dynamic UI updates.",
    details: "<b>Focus:</b> fetch, promises, async/await, error handling and DOM updates.<br><br><b>Lesson:</b> real-world apps need to handle both successful data and things going wrong."
  },
  games: {
    type: "Interactive app",
    title: "Riddle & Memory",
    description: "Small browser-game experiments used to sharpen event handling, state management and DOM manipulation.",
    details: "<b>Focus:</b> click events, game state, timers, matching logic and feedback.<br><br><b>Lesson:</b> games are a fun way to make JavaScript concepts impossible to ignore."
  }
};

const modal = $("#projectModal");
const modalTitle = $("#modalTitle");
const modalType = $("#modalType");
const modalDescription = $("#modalDescription");
const modalDetails = $("#modalDetails");

$$("[data-project]").forEach(button => {
  button.addEventListener("click", () => {
    const project = projects[button.dataset.project];
    if (!project) return;
    modalType.textContent = project.type;
    modalTitle.textContent = project.title;
    modalDescription.textContent = project.description;
    modalDetails.innerHTML = project.details;
    modal.classList.add("open");
    modal.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
  });
});

function closeModal() {
  modal.classList.remove("open");
  modal.setAttribute("aria-hidden", "true");
  document.body.style.overflow = "";
}
$("#modalClose").addEventListener("click", closeModal);
modal.addEventListener("click", e => { if (e.target === modal) closeModal(); });
document.addEventListener("keydown", e => { if (e.key === "Escape") closeModal(); });

const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) entry.target.classList.add("visible");
  });
}, {threshold: 0.12});
$$(".reveal").forEach(el => observer.observe(el));

$("#year").textContent = new Date().getFullYear();

const copyEmail = $("#copyEmail");
copyEmail.addEventListener("click", async () => {
  const email = "favouroriasotie090@gmail.com";
  try {
    await navigator.clipboard.writeText(email);
    copyEmail.textContent = "Copied ✓";
  } catch {
    copyEmail.textContent = email;
  }
  setTimeout(() => copyEmail.textContent = "Copy email", 1800);
});

const glow = $(".cursor-glow");
window.addEventListener("pointermove", e => {
  glow.style.left = `${e.clientX}px`;
  glow.style.top = `${e.clientY}px`;
});

document.querySelectorAll("a[href^='#']").forEach(link => {
  link.addEventListener("click", e => {
    const target = document.querySelector(link.getAttribute("href"));
    if (!target) return;
    e.preventDefault();
    target.scrollIntoView({behavior:"smooth", block:"start"});
  });
});
